'use client';

import { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/utils';

interface FadeInProps {
  children: React.ReactNode;
  delay?: number;
  className?: string;
  direction?: 'up' | 'none';
  threshold?: number;
}

/**
 * FadeIn — intersects into view, fades and translates up.
 * Respects prefers-reduced-motion via CSS (transition-duration near-zero).
 */
export function FadeIn({ children, delay = 0, className, direction = 'up', threshold = 0.1 }: FadeInProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [threshold]);

  return (
    <div
      ref={ref}
      className={cn(
        'motion-reduce:transition-none motion-reduce:opacity-100 motion-reduce:translate-y-0',
        'transition-[opacity,transform] duration-700 ease-out',
        visible
          ? 'opacity-100 translate-y-0'
          : cn('opacity-0', direction === 'up' ? 'translate-y-5' : ''),
        className
      )}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}
