'use client';

import { useState } from 'react';
import { Button } from './Button';

type Status = 'idle' | 'loading' | 'success' | 'error';

interface WaitlistFormProps {
  variant?: 'inline' | 'stacked';
  label?: string;
}

export function WaitlistForm({ variant = 'inline', label }: WaitlistFormProps) {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [status, setStatus] = useState<Status>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim()) return;

    setStatus('loading');
    setErrorMsg('');

    try {
      const res = await fetch('/api/waitlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), name: name.trim() }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message ?? 'Something went wrong');
      }

      setStatus('success');
      setEmail('');
      setName('');
    } catch (err) {
      setStatus('error');
      setErrorMsg(err instanceof Error ? err.message : 'Please try again.');
    }
  }

  if (status === 'success') {
    return (
      <div className="text-center py-4">
        <p className="font-serif text-xl font-light text-charcoal mb-2">You&apos;re on the list.</p>
        <p className="font-sans text-sm text-stone-500 leading-relaxed">
          We&apos;ll reach out before Altitude I opens. In the meantime — thank you.
        </p>
      </div>
    );
  }

  if (variant === 'stacked') {
    return (
      <form onSubmit={handleSubmit} className="flex flex-col gap-6 w-full max-w-sm">
        {label && (
          <p className="label">{label}</p>
        )}
        <div className="flex flex-col gap-5">
          <div>
            <label htmlFor="waitlist-name-s" className="sr-only">Your name</label>
            <input
              id="waitlist-name-s"
              type="text"
              autoComplete="name"
              placeholder="Your name"
              value={name}
              onChange={e => setName(e.target.value)}
              className="input-luxury"
            />
          </div>
          <div>
            <label htmlFor="waitlist-email-s" className="sr-only">Email address</label>
            <input
              id="waitlist-email-s"
              type="email"
              required
              autoComplete="email"
              placeholder="Email address"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="input-luxury"
            />
          </div>
        </div>
        {errorMsg && <p className="text-xs text-stone-500">{errorMsg}</p>}
        <Button type="submit" variant="primary" disabled={status === 'loading'} className="w-full">
          {status === 'loading' ? 'One moment…' : 'Request Early Access'}
        </Button>
        <p className="font-sans text-[0.6875rem] text-stone-400 leading-relaxed">
          We respect your privacy. No newsletters, no spam. Only early access to Altitude I.
        </p>
      </form>
    );
  }

  // inline variant
  return (
    <form onSubmit={handleSubmit} className="w-full">
      {label && <p className="label mb-4">{label}</p>}
      <div className="flex flex-col sm:flex-row gap-3 items-end">
        <div className="flex-1">
          <label htmlFor="waitlist-email-i" className="sr-only">Email address</label>
          <input
            id="waitlist-email-i"
            type="email"
            required
            autoComplete="email"
            placeholder="Your email address"
            value={email}
            onChange={e => setEmail(e.target.value)}
            className="input-luxury"
          />
        </div>
        <Button type="submit" variant="primary" size="sm" disabled={status === 'loading'}>
          {status === 'loading' ? 'Joining…' : 'Join Waitlist'}
        </Button>
      </div>
      {errorMsg && <p className="text-xs text-stone-500 mt-2">{errorMsg}</p>}
    </form>
  );
}
