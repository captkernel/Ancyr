import type { Metadata } from 'next';
import { FadeIn } from '@/components/sections/FadeIn';
import { Button } from '@/components/ui/Button';

export const metadata: Metadata = {
  title: 'FAQ – ANCYR',
  description: 'Answers to common questions about Angora, our process, care instructions, authenticity, and provenance.',
};

const faqs = [
  {
    category: 'The Fibre',
    items: [
      {
        q: 'What is Angora fibre?',
        a: 'Angora fibre comes from the Angora rabbit — not to be confused with Angora goat, which produces mohair. It is one of the finest natural fibres in the world, with a diameter of 11–16 microns. Its hollow core makes it extremely warm for its weight, and its natural halo gives it the characteristic softness and luminosity.',
      },
      {
        q: 'What is the difference between 100% Angora and Angora blends?',
        a: 'A 100% Angora product contains only Angora fibre — no wool, no acrylic, no synthetic. Blends typically mix Angora with wool (often 30–70% Angora) or synthetic fibres. Blends are less expensive to produce and easier to process, which is why many products described as "Angora" are blends. ANCYR clearly states composition on every product. When we say 100%, we mean it.',
      },
      {
        q: 'How can I tell if something is really 100% Angora?',
        a: 'Genuinely, it is difficult without testing. Fibre composition can be assessed through microscopic examination or chemical analysis. We maintain lot-level documentation and are working toward accessible composition verification for our customers. In the meantime, the honest answer is: buy from producers who document their supply chain.',
      },
      {
        q: 'Why is 100% Angora rare?',
        a: 'Angora is difficult and expensive to process at 100% purity. The fibre has very little natural crimp, which makes it challenging to spin into a stable yarn. Blending it with wool provides structure at lower cost. Producing 100% Angora requires significant craft knowledge and is more expensive throughout the supply chain — which is why most "Angora" products in the market are blends.',
      },
    ],
  },
  {
    category: 'Care & Longevity',
    items: [
      {
        q: 'How should I care for my ANCYR shawl or stole?',
        a: 'Dry clean is recommended for all pieces. If hand washing is necessary, use cold water with a gentle wool wash detergent — do not rub or wring. Lay flat to dry on a clean towel, reshaping while damp. Store folded in breathable cotton, away from direct sunlight and moisture. Do not hang, as the weight can stretch the fibre over time.',
      },
      {
        q: 'My shawl is pilling. Is that normal?',
        a: 'Light surface pilling can occur with any natural fibre and is not a quality defect. For Angora, some initial shedding and pilling is normal — it reduces after the first few wears. Use a soft-bristle garment brush to gently remove surface fuzz. Avoid friction against rough surfaces.',
      },
      {
        q: 'How long will a 100% Angora shawl last?',
        a: 'With proper care, a well-made Angora shawl can last decades. The fibre does not degrade under normal use. The keys are correct washing, proper storage, and protecting the piece from moths (cedar or lavender sachets work well). Angora does not felt under normal washing conditions, unlike wool.',
      },
    ],
  },
  {
    category: 'ANCYR & Provenance',
    items: [
      {
        q: 'Where is ANCYR based?',
        a: 'ANCYR is an India-first luxury house. Our production is based in Kullu, Himachal Pradesh. Our founding knowledge goes back to 1965. We are a family operation.',
      },
      {
        q: 'Do you manufacture everything yourself?',
        a: 'Yes. We operate our own production facility. Combing, spinning, weaving, and finishing all happen under our oversight. This is unusual in the luxury fibre space, and it is precisely why we can make claims about composition and process with confidence.',
      },
      {
        q: 'When does Altitude I launch? Can I buy now?',
        a: 'Altitude I — Light Edition launches in 2026. It is not available for purchase yet. You can join the waitlist to receive early access before the public launch.',
      },
      {
        q: 'Do you ship internationally?',
        a: 'ANCYR is India-first. Our launch and initial years are focused on the Indian luxury market and the Indian diaspora. International shipping and expansion is planned for 2028 onwards.',
      },
    ],
  },
];

export default function FAQPage() {
  return (
    <>
      <section className="pt-40 pb-16 bg-ivory">
        <div className="container-editorial">
          <FadeIn>
            <p className="label mb-6">Frequently Asked</p>
            <h1 className="font-serif font-light text-display-xl text-charcoal max-w-2xl leading-[1.08]">
              Questions about Angora,<br />care, and provenance.
            </h1>
          </FadeIn>
        </div>
      </section>

      <section className="section bg-ivory">
        <div className="container-editorial max-w-3xl">
          {faqs.map((section, si) => (
            <FadeIn key={section.category} delay={si * 60}>
              <div className="mb-16">
                <p className="label mb-8">{section.category}</p>
                <div className="space-y-8">
                  {section.items.map((item, i) => (
                    <div key={i} className="border-t border-stone-200 pt-6">
                      <h3 className="font-serif font-medium text-lg text-charcoal mb-3">{item.q}</h3>
                      <p className="font-sans text-sm text-stone-500 leading-relaxed">{item.a}</p>
                    </div>
                  ))}
                </div>
              </div>
            </FadeIn>
          ))}

          <FadeIn>
            <div className="border-t border-stone-200 pt-10">
              <h2 className="font-serif font-light text-2xl text-charcoal mb-3">Have another question?</h2>
              <p className="font-sans text-sm text-stone-500 mb-6">We are a small team. We respond to every message personally.</p>
              <Button href="/contact" variant="outline">Get in Touch</Button>
            </div>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
