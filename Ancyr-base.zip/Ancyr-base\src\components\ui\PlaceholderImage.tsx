import { cn } from '@/lib/utils';

interface PlaceholderImageProps {
  label?: string;
  aspectRatio?: '1/1' | '3/4' | '4/3' | '16/9' | '2/3' | '5/4' | '3/2';
  className?: string;
  tone?: 'light' | 'medium' | 'dark';
  overlay?: boolean;
  src?: string;
}

const toneMap = {
  light:  'bg-stone-50',
  medium: 'bg-stone-100',
  dark:   'bg-stone-200',
};

const ratioMap = {
  '1/1':  'aspect-square',
  '3/4':  'aspect-[3/4]',
  '4/3':  'aspect-[4/3]',
  '16/9': 'aspect-video',
  '2/3':  'aspect-[2/3]',
  '5/4':  'aspect-[5/4]',
  '3/2':  'aspect-[3/2]',
};

/**
 * Brand Image — renders an SVG image asset, or falls back to styled placeholder.
 * Replace src with next/image once real photography is available.
 */
export function PlaceholderImage({
  label = 'Photography',
  aspectRatio = '3/4',
  className,
  tone = 'medium',
  overlay = false,
  src,
}: PlaceholderImageProps) {
  return (
    <div
      className={cn(
        'relative overflow-hidden w-full',
        ratioMap[aspectRatio],
        !src && toneMap[tone],
        className
      )}
      role="img"
      aria-label={label}
    >
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={src}
          alt={label}
          className="absolute inset-0 w-full h-full object-cover"
        />
      ) : (
        <>
          {/* Subtle grain texture via SVG */}
          <svg
            className="absolute inset-0 w-full h-full opacity-[0.04] pointer-events-none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <filter id="noise">
              <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="3" stitchTiles="stitch" />
              <feColorMatrix type="saturate" values="0" />
            </filter>
            <rect width="100%" height="100%" filter="url(#noise)" />
          </svg>

          {/* Photo direction label */}
          <div className="absolute inset-0 flex items-center justify-center p-6">
            <span className="font-sans text-[0.5625rem] font-medium tracking-[0.2em] uppercase text-stone-400 text-center leading-relaxed">
              {label}
            </span>
          </div>
        </>
      )}

      {overlay && (
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-charcoal/30" />
      )}
    </div>
  );
}
