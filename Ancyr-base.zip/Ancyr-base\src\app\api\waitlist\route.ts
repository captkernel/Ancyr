import { NextRequest, NextResponse } from 'next/server';

interface WaitlistEntry {
  email: string;
  name?: string;
  timestamp: string;
  source: string;
}

/**
 * POST /api/waitlist
 *
 * Accepts email + optional name, logs the submission.
 * Ready to integrate with: Resend, ConvertKit, Mailchimp, Supabase, etc.
 *
 * Integration notes:
 * - Resend: POST to https://api.resend.com/audiences/{id}/contacts
 * - ConvertKit: POST to https://api.convertkit.com/v3/forms/{id}/subscribe
 * - Supabase: use @supabase/supabase-js client to insert into a waitlist table
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, name } = body as { email?: string; name?: string };

    if (!email || !email.includes('@')) {
      return NextResponse.json({ message: 'A valid email address is required.' }, { status: 400 });
    }

    const entry: WaitlistEntry = {
      email: email.toLowerCase().trim(),
      name: name?.trim() || undefined,
      timestamp: new Date().toISOString(),
      source: 'ancyr.in',
    };

    // Log submission for development
    console.log('[ANCYR Waitlist]', entry);

    // TODO: Replace with your integration of choice:
    // await sendToResend(entry);
    // await sendToConvertKit(entry);
    // await saveToSupabase(entry);

    return NextResponse.json(
      { message: 'You are on the list. We will be in touch.' },
      { status: 200 }
    );
  } catch {
    return NextResponse.json(
      { message: 'Something went wrong. Please try again.' },
      { status: 500 }
    );
  }
}
